<?php

defined('MOODLE_INTERNAL') || die();

$messageproviders = array(
    'begateway_enrolment' => array(),
);
