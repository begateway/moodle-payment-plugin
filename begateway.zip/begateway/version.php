<?php

defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2023090900;        // The current plugin version (Date: YYYYMMDDXX)
$plugin->requires  = 2012112900;        // Requires this Moodle version
$plugin->component = 'enrol_begateway';    // Full name of the plugin (used for diagnostics)
